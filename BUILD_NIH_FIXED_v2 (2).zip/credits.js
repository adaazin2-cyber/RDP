const fs = require("fs");
const path = require("path");
const axios = require("axios");

// ─── PATHS ───────────────────────────────────────────────────────────────────
const DATA_DIR       = "./data_credits";
const CREDITS_PATH   = path.join(DATA_DIR, "credits.json");
const REDEEM_PATH    = path.join(DATA_DIR, "redeem.json");
const DEPLOYS_PATH   = path.join(DATA_DIR, "deploys.json");
const BUYERS_PATH    = path.join(DATA_DIR, "buyers.json");

const START_CREDIT    = 0; // kredit berbayar awal (user baru dapat kredit gratis harian)
const DAILY_FREE_CREDIT = 5; // kredit gratis per hari (reset tiap hari WIB)
const REFERRAL_BONUS  = 5; // credit yang didapat pembagi link kalau referral-nya join

function ensureDir() { if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true }); }
function ensureJson(p, def) { ensureDir(); if (!fs.existsSync(p)) fs.writeFileSync(p, JSON.stringify(def, null, 2)); }
ensureJson(CREDITS_PATH, {});
ensureJson(REDEEM_PATH, {});
ensureJson(DEPLOYS_PATH, []);
ensureJson(BUYERS_PATH, []);

function readJson(p) { return JSON.parse(fs.readFileSync(p, "utf-8")); }
function writeJson(p, d) { fs.writeFileSync(p, JSON.stringify(d, null, 2)); }

// ─── CREDITS ─────────────────────────────────────────────────────────────────
function todayKey() {
  // Tanggal WIB (YYYY-MM-DD), dipakai untuk reset kredit harian
  return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Jakarta" });
}

function newRecord() {
  return {
    credits: 0,           // kredit berbayar (tidak hangus)
    dailyFree: DAILY_FREE_CREDIT,
    dailyDate: todayKey(),
    joinedAt: new Date().toISOString(),
    refBy: null,
    refConfirmed: false,
  };
}

// Pastikan field harian ada dan sudah di-reset kalau ganti hari
function refreshDaily(rec) {
  const t = todayKey();
  if (rec.dailyDate !== t || typeof rec.dailyFree !== "number") {
    rec.dailyDate = t;
    rec.dailyFree = DAILY_FREE_CREDIT;
  }
}

// Total saldo = kredit gratis hari ini + kredit berbayar
function getCredits(userId) {
  const all = readJson(CREDITS_PATH);
  const rec = all[String(userId)];
  if (!rec) return DAILY_FREE_CREDIT;
  const free = rec.dailyDate === todayKey() && typeof rec.dailyFree === "number"
    ? rec.dailyFree
    : DAILY_FREE_CREDIT;
  return free + (rec.credits || 0);
}

// Panggil tiap kali /start. User baru dapat kredit gratis harian (START_CREDIT = 0 untuk kredit berbayar).
function ensureUser(userId, refByRaw = null) {
  const all = readJson(CREDITS_PATH);
  const key = String(userId);
  if (all[key]) {
    refreshDaily(all[key]);
    writeJson(CREDITS_PATH, all);
    return { isNew: false, credits: getCredits(userId) };
  }

  const refBy = Number(refByRaw);
  const rec = newRecord();
  rec.refBy = (refBy && refBy !== Number(userId)) ? refBy : null;
  all[key] = rec;
  writeJson(CREDITS_PATH, all);
  return { isNew: true, credits: getCredits(userId) };
}

// Tambah kredit berbayar (hanya dipanggil oleh owner / pembelian / referral / redeem)
function addCredits(userId, amount) {
  const all = readJson(CREDITS_PATH);
  const key = String(userId);
  if (!all[key]) all[key] = newRecord();
  refreshDaily(all[key]);
  all[key].credits = (all[key].credits || 0) + Number(amount);
  writeJson(CREDITS_PATH, all);
  return getCredits(userId);
}

// Set kredit berbayar ke nilai tertentu
function setCredits(userId, amount) {
  const all = readJson(CREDITS_PATH);
  const key = String(userId);
  if (!all[key]) all[key] = newRecord();
  refreshDaily(all[key]);
  all[key].credits = Number(amount);
  writeJson(CREDITS_PATH, all);
  return getCredits(userId);
}

function hasCredit(userId, amount = 1) { return getCredits(userId) >= amount; }

// Potong kredit: pakai kredit gratis hari ini dulu, sisanya dari kredit berbayar.
// Return false kalau saldo kurang (tidak ada yang dipotong).
function deductCredit(userId, amount = 1) {
  const all = readJson(CREDITS_PATH);
  const key = String(userId);
  if (!all[key]) all[key] = newRecord();
  const rec = all[key];
  refreshDaily(rec);

  const total = rec.dailyFree + (rec.credits || 0);
  if (total < amount) return false;

  const fromFree = Math.min(rec.dailyFree, amount);
  rec.dailyFree -= fromFree;
  const rest = amount - fromFree;
  rec.credits = (rec.credits || 0) - rest;

  writeJson(CREDITS_PATH, all);
  return true;
}

// ─── REFERRAL ────────────────────────────────────────────────────────────────
// Dipanggil setelah user berhasil lolos verifikasi join channel (baru dikonfirmasi sekali).
// Return userId pembagi link kalau bonus baru saja diberikan, else null.
function confirmReferral(userId) {
  const all = readJson(CREDITS_PATH);
  const key = String(userId);
  const u = all[key];
  if (!u || !u.refBy || u.refConfirmed) return null;

  u.refConfirmed = true;
  const refKey = String(u.refBy);
  if (!all[refKey]) all[refKey] = { credits: 0, joinedAt: new Date().toISOString(), refBy: null, refConfirmed: false };
  all[refKey].credits = (all[refKey].credits || 0) + REFERRAL_BONUS;

  writeJson(CREDITS_PATH, all);
  return u.refBy;
}

function getReferralStats(userId) {
  const all = readJson(CREDITS_PATH);
  const key = String(userId);
  let confirmedCount = 0, pendingCount = 0;
  for (const k in all) {
    if (Number(all[k].refBy) === Number(userId)) {
      if (all[k].refConfirmed) confirmedCount++;
      else pendingCount++;
    }
  }
  return {
    credits: all[key]?.credits ?? 0,
    confirmedReferrals: confirmedCount,
    pendingReferrals: pendingCount,
  };
}

// ─── REDEEM CODE ─────────────────────────────────────────────────────────────
function generateCodeString(len = 8) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

function createRedeemCode(creditAmount, maxUses = 1, createdBy) {
  const all = readJson(REDEEM_PATH);
  let code;
  do { code = generateCodeString(); } while (all[code]);
  all[code] = {
    credits: Number(creditAmount),
    maxUses: Number(maxUses) || 1,
    uses: 0,
    usedBy: [],
    createdBy: Number(createdBy),
    createdAt: new Date().toISOString(),
  };
  writeJson(REDEEM_PATH, all);
  return code;
}

function redeemCode(userId, rawCode) {
  const code = String(rawCode || "").trim().toUpperCase();
  const all = readJson(REDEEM_PATH);
  const c = all[code];
  if (!c) return { ok: false, reason: "notfound" };
  if (c.uses >= c.maxUses) return { ok: false, reason: "exhausted" };
  if (c.usedBy.includes(Number(userId))) return { ok: false, reason: "already" };

  c.uses += 1;
  c.usedBy.push(Number(userId));
  writeJson(REDEEM_PATH, all);
  addCredits(userId, c.credits);
  return { ok: true, credits: c.credits };
}

function listRedeemCodes() { return readJson(REDEEM_PATH); }

// ─── DEPLOY LOG (khusus owner, tidak ditampilkan ke channel/user lain) ──────
function logDeploy(entry) {
  const all = readJson(DEPLOYS_PATH);
  all.push({ ...entry, at: new Date().toISOString() });
  writeJson(DEPLOYS_PATH, all);
}

function getAllDeploys() { return readJson(DEPLOYS_PATH); }

// ─── BUYERS (list "terima kasih" pembeli credit) ────────────────────────────
function addBuyer(userId, username, amountIDR, creditsGiven, approvedBy) {
  const all = readJson(BUYERS_PATH);
  all.push({
    userId: Number(userId), username: username || "—",
    amountIDR: Number(amountIDR) || 0, creditsGiven: Number(creditsGiven) || 0,
    approvedBy: Number(approvedBy), at: new Date().toISOString(),
  });
  writeJson(BUYERS_PATH, all);
}

function getBuyers() { return readJson(BUYERS_PATH); }

// ─── GITHUB BACKUP (biar kalau server mati, data user/credit tetap aman) ────
let _ghToken = null, _ghUser = null, _ghRepo = "bot-database-backup";

function initGithub(token, username, repo) {
  _ghToken = token;
  _ghUser  = username;
  if (repo) _ghRepo = repo;
}

function isGithubConfigured() { return !!(_ghToken && _ghUser); }

async function backupToGithub(extraFilesMap = {}) {
  if (!isGithubConfigured()) return { ok: false, reason: "not_configured" };

  const hdr = {
    Authorization: `token ${_ghToken}`,
    "Content-Type": "application/json",
    "User-Agent": "CreditBackup-Bot/1.0",
    Accept: "application/vnd.github.v3+json",
  };
  const base = "https://api.github.com";

  try {
    try {
      await axios.get(`${base}/repos/${_ghUser}/${_ghRepo}`, { headers: hdr });
    } catch {
      await axios.post(
        `${base}/user/repos`,
        { name: _ghRepo, private: true, auto_init: true, description: "🔒 Auto backup database bot (jangan dihapus)" },
        { headers: hdr }
      );
      await new Promise(r => setTimeout(r, 2000));
    }

    const filesMap = {
      "credits.json": fs.readFileSync(CREDITS_PATH, "utf-8"),
      "redeem.json": fs.readFileSync(REDEEM_PATH, "utf-8"),
      "deploys.json": fs.readFileSync(DEPLOYS_PATH, "utf-8"),
      "buyers.json": fs.readFileSync(BUYERS_PATH, "utf-8"),
      ...extraFilesMap, // caller kirim users.json, resellers.json, dll dari index.js
    };

    for (const [name, content] of Object.entries(filesMap)) {
      let sha = null;
      try {
        const r = await axios.get(`${base}/repos/${_ghUser}/${_ghRepo}/contents/${name}`, { headers: hdr });
        sha = r.data.sha;
      } catch {}

      const body = {
        message: `🔄 Auto backup - ${new Date().toISOString()}`,
        content: Buffer.from(content, "utf-8").toString("base64"),
      };
      if (sha) body.sha = sha;

      await axios.put(`${base}/repos/${_ghUser}/${_ghRepo}/contents/${name}`, body, { headers: hdr });
    }

    return { ok: true, repo: `${_ghUser}/${_ghRepo}`, url: `https://github.com/${_ghUser}/${_ghRepo}` };
  } catch (err) {
    return { ok: false, reason: err.response?.data?.message || err.message };
  }
}

// ─── LOCAL BACKUP (Download semua file data_credits sebagai ZIP) ──────────────
function createLocalBackupZip() {
  const AdmZip = require("adm-zip");
  const zip = new AdmZip();
  
  // Tambahkan semua file JSON dari data_credits
  if (fs.existsSync(CREDITS_PATH)) {
    zip.addFile("credits.json", Buffer.from(fs.readFileSync(CREDITS_PATH, "utf-8")));
  }
  if (fs.existsSync(REDEEM_PATH)) {
    zip.addFile("redeem.json", Buffer.from(fs.readFileSync(REDEEM_PATH, "utf-8")));
  }
  if (fs.existsSync(DEPLOYS_PATH)) {
    zip.addFile("deploys.json", Buffer.from(fs.readFileSync(DEPLOYS_PATH, "utf-8")));
  }
  if (fs.existsSync(BUYERS_PATH)) {
    zip.addFile("buyers.json", Buffer.from(fs.readFileSync(BUYERS_PATH, "utf-8")));
  }
  
  // Tambahkan info metadata
  const metadata = {
    backupAt: new Date().toISOString(),
    dataDir: DATA_DIR,
    filesIncluded: ["credits.json", "redeem.json", "deploys.json", "buyers.json"]
  };
  zip.addFile("BACKUP_INFO.json", Buffer.from(JSON.stringify(metadata, null, 2)));
  
  return zip;
}

function getLocalBackupPath() {
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").split("T")[0];
  const backupDir = path.join(path.dirname(DATA_DIR), "backups");
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
  return path.join(backupDir, `data_credits_backup_${timestamp}.zip`);
}

function downloadLocalBackup() {
  try {
    const zip = createLocalBackupZip();
    const backupPath = getLocalBackupPath();
    zip.writeZip(backupPath);
    return { ok: true, path: backupPath, size: fs.statSync(backupPath).size };
  } catch (err) {
    return { ok: false, reason: err.message };
  }
}

module.exports = {
  START_CREDIT, DAILY_FREE_CREDIT, REFERRAL_BONUS,
  ensureUser, getCredits, addCredits, setCredits, hasCredit, deductCredit,
  confirmReferral, getReferralStats,
  createRedeemCode, redeemCode, listRedeemCodes,
  logDeploy, getAllDeploys,
  addBuyer, getBuyers,
  initGithub, isGithubConfigured, backupToGithub,
  createLocalBackupZip, downloadLocalBackup, getLocalBackupPath,
};
