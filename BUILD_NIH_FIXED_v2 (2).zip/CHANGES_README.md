# Update fitur

Versi ini menambahkan menu Tools/Tools+ yang mengikuti fitur pada referensi screenshot, termasuk:
- Ganti Aset, Nama APK, API/Script, Fix API/Script (AI Gemini)
- Get Aset, HTML -> JS, Preview Data, Enc Menu
- Cari Project, Scan Info, Bersihkan ZIP
- Antrean, Statistik, Status Bot, Ping, Credit, Buy Credit, Panduan, Feedback, Laporkan Bug
- Recolour, Multi Recolour, Ganti Function, Tes Function
- Fix Base Error, Fix Error Kode .dart (AI), To URL, Copy Tampilan -> .dart
- Group Menu dan Chat AI

Fitur lokal yang tidak membutuhkan provider eksternal sudah dibuat operasional, seperti scan info project, daftar asset, pembersihan ZIP, HTML -> JS sederhana, dan multi-recolour.
Fitur AI/hosting publik yang membutuhkan provider tidak dibuat-buat: bot memberi instruksi konfigurasi provider terlebih dahulu.

Menu utama dan submenu Tools/Tools+ menggunakan animasi indikator warna yang berganti setiap 1 detik.
Catatan: Telegram/GramJS standar tidak memberi bot kontrol bebas atas warna background tombol inline. Karena itu animasi dilakukan pada indikator warna di label tombol, bukan memaksa warna background Telegram.
