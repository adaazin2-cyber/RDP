// ============================================================
//  server.js — helper GitHub (Release, Workflow, Artifact)
//  Dipakai oleh index.js. Token dibaca dari config.js / env.
//  Versi ini sudah ditulis ulang agar bisa dibaca dan diaudit.
// ============================================================

const fs = require("fs");
const axios = require("axios");
const CONFIG = require("./config");

const GH = "https://api.github.com";

// ─── UTIL ────────────────────────────────────────────────────

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Terima format "owner/repo", "https://github.com/owner/repo", atau "owner/repo.git"
function repo() {
  let r = String(CONFIG.BUILD_REPO || "").trim();
  r = r.replace(/^https?:\/\/github\.com\//i, "").replace(/\.git$/i, "").replace(/\/+$/, "");
  if (!r) throw new Error("BUILD_REPO belum diisi (format: owner/repo)");
  if (!/^[\w.-]+\/[\w.-]+$/.test(r)) {
    throw new Error(`BUILD_REPO salah format: "${CONFIG.BUILD_REPO}" (harus owner/repo)`);
  }
  return r;
}

// Nama file workflow (tanpa path). Terima "build-apk.yml" atau ".github/workflows/build-apk.yml"
function workflowFile() {
  const f = String(CONFIG.BUILD_WORKFLOW || "build-apk.yml").trim();
  return f.replace(/^\.github\/workflows\//, "");
}

// Cek repo & workflow sebelum upload, supaya tidak ada release yatim dan pesan errornya jelas
async function preflightBuildRepo() {
  const r = repo();
  try {
    await gh("get", `/repos/${r}`);
  } catch (err) {
    throw new Error(
      `Repo "${r}" tidak ditemukan / token tidak punya akses. Cek BUILD_REPO dan GITHUB_TOKEN (scope repo + workflow).`
    );
  }
  try {
    await gh("get", `/repos/${r}/actions/workflows/${workflowFile()}`);
  } catch (err) {
    throw new Error(
      `Workflow "${workflowFile()}" tidak ada di repo ${r} (branch ${CONFIG.GITHUB_REF || "main"}). ` +
      `Upload file .github/workflows/${workflowFile()} ke repo tersebut, lalu coba lagi.`
    );
  }
}

function authHeaders(extra = {}) {
  if (!CONFIG.GITHUB_TOKEN) {
    throw new Error("GITHUB_TOKEN belum diisi (env atau config.js)");
  }
  return {
    Authorization: `Bearer ${CONFIG.GITHUB_TOKEN}`,
    Accept: "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
    "User-Agent": "bot-build-apk",
    ...extra,
  };
}

// Request ke GitHub dengan pesan error yang jelas
async function gh(method, pathOrUrl, data, opts = {}) {
  const url = pathOrUrl.startsWith("http") ? pathOrUrl : `${GH}${pathOrUrl}`;
  try {
    return await axios({
      method,
      url,
      data,
      headers: authHeaders(opts.headers),
      responseType: opts.responseType || "json",
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });
  } catch (err) {
    const status = err.response?.status || "";
    const message = err.response?.data?.message || err.message;
    const where = `${method.toUpperCase()} ${url.replace(GH, "")}`;
    throw new Error(`GitHub ${status}: ${message} [${where}]`);
  }
}

// Upload URL dari GitHub berbentuk ".../assets{?name,label}", buang bagian template
function cleanUploadUrl(uploadUrl) {
  return uploadUrl.replace(/\{.*\}$/, "");
}

// ─── RELEASE ─────────────────────────────────────────────────

// Buat release kosong (draft) untuk aset yang akan diupload nanti
async function createReleaseOnly(tag) {
  const res = await gh("post", `/repos/${repo()}/releases`, {
    tag_name: tag,
    name: tag,
    draft: true,
    body: "Auto release dari bot build APK",
  });
  return {
    releaseId: res.data.id,
    uploadUrl: cleanUploadUrl(res.data.upload_url),
  };
}

// Upload satu file ke release (uploadUrl dari createReleaseOnly)
async function uploadAssetFile(uploadUrl, filePath, name, contentType = "application/octet-stream") {
  const buffer = fs.readFileSync(filePath);
  const res = await gh(
    "post",
    `${uploadUrl}?name=${encodeURIComponent(name)}`,
    buffer,
    { headers: { "Content-Type": contentType, "Content-Length": buffer.length } }
  );
  return res.data;
}

// Ubah release dari draft menjadi publik, lalu kembalikan URL aset pertama
async function publishRelease(releaseId) {
  await gh("patch", `/repos/${repo()}/releases/${releaseId}`, { draft: false });
  const assets = await gh("get", `/repos/${repo()}/releases/${releaseId}/assets`);
  return assets.data[0]?.browser_download_url || null;
}

// Buat release publik untuk ZIP project, lalu upload ZIP-nya
async function uploadZipToRelease(localZip, fileName, tag) {
  await preflightBuildRepo();
  const { releaseId, uploadUrl } = await createReleaseOnly(tag);
  try {
    const asset = await uploadAssetFile(uploadUrl, localZip, fileName, "application/zip");
    await gh("patch", `/repos/${repo()}/releases/${releaseId}`, { draft: false });
    return { releaseId, browserUrl: asset.browser_download_url };
  } catch (err) {
    await deleteRelease(releaseId).catch(() => {});
    throw err;
  }
}

// Hapus release (dipanggil saat build selesai / gagal). Error diabaikan agar tidak menghentikan bot.
async function deleteRelease(releaseId) {
  if (!releaseId) return false;
  await gh("delete", `/repos/${repo()}/releases/${releaseId}`);
  return true;
}

// ─── WORKFLOW ────────────────────────────────────────────────

// Cari run terbaru dari workflow setelah waktu tertentu (dispatch tidak mengembalikan run id)
async function findRunId(since) {
  const file = workflowFile();
  for (let i = 0; i < 15; i++) {
    await sleep(2000);
    const res = await gh("get", `/repos/${repo()}/actions/runs?event=workflow_dispatch&per_page=10`);
    const run = (res.data.workflow_runs || []).find(
      (r) => r.path === `.github/workflows/${file}` && Date.parse(r.created_at) >= since - 5000
    );
    if (run) return run.id;
  }
  throw new Error("Run workflow tidak ditemukan setelah dispatch");
}

async function dispatchWorkflow(inputs) {
  const since = Date.now();
  await gh("post", `/repos/${repo()}/actions/workflows/${workflowFile()}/dispatches`, {
    ref: CONFIG.GITHUB_REF || "main",
    inputs,
  });
  return findRunId(since);
}

// Jalankan workflow build Flutter dari ZIP yang sudah diupload ke release
async function triggerWorkflow(browserUrl, tag, buildType = "release") {
  return dispatchWorkflow({
    mode: "flutter",
    zip_url: browserUrl,
    tag,
    build_type: buildType,
  });
}

// Jalankan workflow Web to APK
async function triggerWeb2ApkWorkflow(webUrl, appName, iconUrl) {
  return dispatchWorkflow({
    mode: "web2apk",
    web_url: webUrl,
    app_name: appName || "WebApp",
    icon_url: iconUrl || "",
  });
}

// Status run: { status, conclusion, durationSec, ... }
async function getRunStatus(runId) {
  const res = await gh("get", `/repos/${repo()}/actions/runs/${runId}`);
  const r = res.data;
  const durationSec = Math.max(0, Math.round((Date.parse(r.updated_at) - Date.parse(r.run_started_at || r.created_at)) / 1000));
  return { ...r, durationSec };
}

// Daftar artifact dari run
async function getArtifacts(runId) {
  const res = await gh("get", `/repos/${repo()}/actions/runs/${runId}/artifacts`);
  return res.data.artifacts || [];
}

// Unduh artifact (ZIP) ke file tujuan
async function downloadArtifactZip(artifactId, destPath) {
  const res = await gh(
    "get",
    `/repos/${repo()}/actions/artifacts/${artifactId}/zip`,
    undefined,
    { responseType: "arraybuffer" }
  );
  fs.writeFileSync(destPath, Buffer.from(res.data));
  return destPath;
}

// Ringkasan step yang gagal (untuk ditampilkan ke user)
async function getFailedStepLog(runId) {
  const res = await gh("get", `/repos/${repo()}/actions/runs/${runId}/jobs?filter=latest`);
  const lines = [];
  for (const job of res.data.jobs || []) {
    if (job.conclusion !== "failure") continue;
    const failedSteps = (job.steps || []).filter((s) => s.conclusion === "failure");
    if (failedSteps.length === 0) lines.push(`• ${job.name}`);
    for (const step of failedSteps) lines.push(`• ${job.name} › ${step.name}`);
  }
  return lines.length ? lines.join("\n") : null;
}

// ─── EXPORT ──────────────────────────────────────────────────

module.exports = {
  sleep,
  preflightBuildRepo,
  uploadZipToRelease,
  deleteRelease,
  triggerWorkflow,
  getRunStatus,
  getArtifacts,
  downloadArtifactZip,
  getFailedStepLog,
  createReleaseOnly,
  uploadAssetFile,
  triggerWeb2ApkWorkflow,
  publishRelease,
};
